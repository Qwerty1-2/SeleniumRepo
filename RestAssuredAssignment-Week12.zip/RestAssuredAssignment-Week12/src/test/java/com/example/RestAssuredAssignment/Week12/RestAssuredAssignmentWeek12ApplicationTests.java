package com.example.RestAssuredAssignment.Week12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestAssuredAssignmentWeek12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
