package com.example.RestAssuredAssignment.Week12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestAssuredAssignmentWeek12Application {

	public static void main(String[] args) {
		SpringApplication.run(RestAssuredAssignmentWeek12Application.class, args);
	}

}
